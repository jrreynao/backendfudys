module.exports = 'supersecreto123'; // Cambia esto por una clave segura en producción
